"""RGShows future-release search, using the pinned IMDb scraper transport."""
from datetime import date, timedelta
from imdb import fetch, parsers, queries
from imdb.search import _year

# The upstream search card omits releaseDate. Include that existing schema field
# so future-release grouping does not depend on a second successful detail call.
UPCOMING_QUERY = queries.SEARCH_TITLES.replace(
    "releaseYear { year endYear }", "releaseYear { year endYear }\n  releaseDate { day month year }", 1)

def upcoming_titles(after, query=None, title_type=None, genre=None,
                    start_year=None, end_year=None, cursor=None, country=None):
    try:
        today = date.fromisoformat(after or "")
        if not 1874 <= today.year <= 2100:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError("after must be an ISO date (YYYY-MM-DD), year 1874-2100")
    start = today + timedelta(days=1)
    lower, upper = _year("start_year",start_year), _year("end_year",end_year)
    if lower:
        start = max(start,date(lower,1,1))
    end = date(upper,12,31) if upper else None
    kind = (title_type or "movie").strip().lower()
    if kind not in queries.TITLE_TYPE_IDS:
        raise ValueError("type must be movie or tv")
    country = queries.normalize_country(country)
    constraints = {"titleTypeConstraint":{"anyTitleTypeIds":queries.TITLE_TYPE_IDS[kind]}}
    if genre:
        genre = next((g for g in queries.GENRES if g.lower()==genre.strip().lower()),None)
        if not genre:
            raise ValueError("Unsupported genre")
        constraints["genreConstraint"] = {"allGenreIds":[genre]}
    query = (query or "").strip()
    if query:
        constraints["titleTextConstraint"] = {"searchTerm":query}
    if end and start>end:
        return {"results":[],"count":0,"pagination":{"total":0,"has_more":False,"next_cursor":None}}
    release_range={"start":start.isoformat()}
    if end:
        release_range["end"]=end.isoformat()
    constraints["releaseDateConstraint"]={"releaseDateRange":release_range}
    variables={"first":50,"constraints":constraints,"sort":{"sortBy":"RELEASE_DATE","sortOrder":"ASC"}}
    if cursor:
        variables["after"]=cursor
    data=fetch.fetch_graphql(UPCOMING_QUERY,variables,country=country)
    results,pagination=parsers.parse_search(data)
    dates={}
    for edge in (data.get("advancedTitleSearch") or {}).get("edges") or []:
        title=((edge.get("node") or {}).get("title") or {})
        parts=title.get("releaseDate") or {}
        year,month,day=parts.get("year"),parts.get("month"),parts.get("day")
        if year:
            try:
                if month and day:
                    value=date(year,month,day).isoformat()
                elif month:
                    date(year,month,1)
                    value=f"{year:04d}-{month:02d}"
                else:
                    value=f"{year:04d}"
                dates[title.get("id")]=value
            except (ValueError,TypeError):
                pass
    for title in results:
        title["release_date"]=dates.get(title.get("id"))
    return {"after":today.isoformat(),"type":kind,"genre":genre,"country":country,"count":len(results),"results":results,"pagination":pagination}

def register(routes):
    if any(path=="/upcoming" for path,_ in routes.ENDPOINTS):
        return
    def handler():
        after,err=routes.required("after")
        return err or routes.call("upcoming",lambda:upcoming_titles(
            after,query=routes.q("query"),title_type=routes.q("type"),genre=routes.q("genre"),
            start_year=routes.q("start_year"),end_year=routes.q("end_year"),cursor=routes.q("cursor"),country=routes.q("country")))
    routes.mount("/upcoming",handler)
    routes.ENDPOINTS.append(("/upcoming",handler))
