"""Self-hosted RGShows metadata API using the pinned omkarcloud scraper."""
from pathlib import Path
import json
import os
import sqlite3
import sys
import time
from urllib.parse import parse_qsl, urlencode

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "upstream"))

class CachedAPI:
    """Persist successful metadata responses; never persist API failures."""
    def __init__(self, app, database):
        self.app = app
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.database) as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("CREATE TABLE IF NOT EXISTS responses (key TEXT PRIMARY KEY, expires REAL, created REAL, body BLOB)")

    def __call__(self, env, start_response):
        path = env.get("PATH_INFO", "")
        ttl = 604800 if path in ("/title/details", "/imdb/title/details") else 21600
        cacheable = env.get("REQUEST_METHOD") == "GET" and path in ("/search", "/title/details", "/imdb/search", "/imdb/title/details", "/upcoming", "/imdb/upcoming")
        if not cacheable:
            return self.app(env, start_response)
        key = path + "?" + urlencode(sorted(parse_qsl(env.get("QUERY_STRING", ""), keep_blank_values=True)))
        now = time.time()
        with sqlite3.connect(self.database) as db:
            row = db.execute("SELECT body, created FROM responses WHERE key=? AND expires>?", (key, now)).fetchone()
        if row:
            body, created = row
            start_response("200 OK", [("Content-Type", "application/json; charset=utf-8"), ("Content-Length", str(len(body))), ("X-RGShows-Cache", "HIT"), ("Age", str(max(0, int(now-created))))])
            return [body]
        captured = {}
        def capture(status, headers, exc_info=None):
            captured.update(status=status, headers=headers)
        response = self.app(env, capture)
        try:
            body = b"".join(response)
        finally:
            if hasattr(response, "close"):
                response.close()
        success = captured["status"].startswith("200 ")
        if success:
            try:
                data = json.loads(body)
                success = isinstance(data, dict) and "error" not in data
            except (ValueError, TypeError):
                success = False
        if success:
            with sqlite3.connect(self.database) as db:
                db.execute("INSERT OR REPLACE INTO responses VALUES (?,?,?,?)", (key, now+ttl, now, body))
                db.execute("DELETE FROM responses WHERE expires < ?", (now,))
        headers = [(k,v) for k,v in captured["headers"] if k.lower() != "content-length"]
        headers += [("Content-Length", str(len(body))), ("X-RGShows-Cache", "MISS")]
        start_response(captured["status"], headers)
        return [body]

def make_app(database=None):
    import bottle
    import routes  # registers the unmodified upstream API endpoints
    import upcoming
    upcoming.register(routes)
    return CachedAPI(bottle.default_app(), database or os.environ.get("CACHE_DB", str(ROOT / "data" / "metadata.sqlite3")))

if __name__ == "__main__":
    from cheroot.wsgi import Server
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    server = Server((host, port), make_app(), numthreads=8)
    print(f"RGShows metadata service listening on {host}:{port}", flush=True)
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()
