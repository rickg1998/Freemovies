import io
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import CachedAPI, make_app

def request(app, path='/search', query='query=matrix', method='GET'):
    result={}
    env={'REQUEST_METHOD':method,'PATH_INFO':path,'QUERY_STRING':query,'SERVER_NAME':'localhost','SERVER_PORT':'8000','SERVER_PROTOCOL':'HTTP/1.1','wsgi.version':(1,0),'wsgi.url_scheme':'http','wsgi.input':io.BytesIO(b''),'wsgi.errors':sys.stderr,'wsgi.multithread':False,'wsgi.multiprocess':False,'wsgi.run_once':False}
    def start(status,headers,exc_info=None):result.update(status=status,headers=dict(headers))
    response=app(env,start)
    try:result['body']=b''.join(response)
    finally:
        if hasattr(response,'close'):response.close()
    return result

def test_cache_reuses_search_and_canonical_query_order(tmp_path):
    calls=[]
    def upstream(env,start):
        calls.append(env['QUERY_STRING']);start('200 OK',[('Content-Type','application/json')]);return [b'{"results":[]}']
    app=CachedAPI(upstream,tmp_path/'cache.db')
    assert request(app,query='query=matrix&type=movie')['headers']['X-RGShows-Cache']=='MISS'
    assert request(app,query='type=movie&query=matrix')['headers']['X-RGShows-Cache']=='HIT'
    assert len(calls)==1

def test_errors_are_never_cached(tmp_path):
    calls=[]
    def upstream(env,start):calls.append(1);start('500 Internal Server Error',[]);return [b'{"error":"upstream unavailable"}']
    app=CachedAPI(upstream,tmp_path/'cache.db')
    request(app);request(app)
    assert len(calls)==2

def test_invalid_and_error_payloads_are_not_cached(tmp_path):
    for body in (b'not json',b'{"error":"failed"}'):
        calls=[]
        def upstream(env,start):calls.append(1);start('200 OK',[]);return [body]
        app=CachedAPI(upstream,tmp_path/str(len(body)))
        request(app);request(app)
        assert len(calls)==2

def test_cache_keeps_filter_and_cursor_variants_separate(tmp_path):
    calls=[]
    def upstream(env,start):calls.append(1);start('200 OK',[]);return [b'{"results":[]}']
    app=CachedAPI(upstream,tmp_path/'cache.db')
    for query in ('genre=Drama','genre=Comedy','genre=Drama&cursor=page2','genre=Drama'):request(app,query=query)
    assert len(calls)==3

def test_expired_cache_refreshes(tmp_path):
    import sqlite3
    calls=[]
    def upstream(env,start):calls.append(1);start('200 OK',[]);return [b'{"results":[]}']
    path=tmp_path/'cache.db';app=CachedAPI(upstream,path);request(app)
    with sqlite3.connect(path) as db:db.execute('UPDATE responses SET expires=0')
    request(app);assert len(calls)==2

def test_health_and_missing_parameters_are_real_routes(tmp_path):
    app=make_app(tmp_path/'cache.db')
    health=request(app,'/health','')
    assert health['status'].startswith('200')
    assert '/search' in json.loads(health['body'])['endpoints']
    missing=request(app,'/title/details','')
    assert missing['status'].startswith('400')
    assert 'title_id' in json.loads(missing['body'])['error']
