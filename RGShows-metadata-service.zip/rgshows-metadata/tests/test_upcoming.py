from datetime import date
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
import upcoming
import pytest
from test_cache import request

@pytest.fixture
def captured(monkeypatch):
    calls=[]
    def graphql(query,variables,**kw):
        calls.append((query,variables,kw))
        return {'advancedTitleSearch':{'edges':[{'node':{'title':{'id':'tt1234567','titleText':{'text':'Future film'},'titleType':{'id':'movie'},'releaseYear':{'year':2027},'releaseDate':{'year':2027,'month':1,'day':15}}}}], 'pageInfo':{'hasNextPage':True,'endCursor':'next'},'total':12}}
    monkeypatch.setattr(upcoming.fetch,'fetch_graphql',graphql)
    return calls

def test_strict_tomorrow_and_nearest_first(captured):
    out=upcoming.upcoming_titles('2026-10-25')
    assert captured[0][1]['constraints']['releaseDateConstraint']['releaseDateRange']=={'start':'2026-10-26'}
    assert captured[0][1]['sort']=={'sortBy':'RELEASE_DATE','sortOrder':'ASC'}
    assert out['results'][0]['release_date']=='2027-01-15'
    assert out['pagination']['next_cursor']=='next'
    assert 'releaseDate { day month year }' in captured[0][0]

def test_year_genre_type_and_cursor(captured):
    upcoming.upcoming_titles('2026-10-25',genre='Sci-Fi',title_type='tv',start_year='2027',end_year='2027',cursor='page2')
    v=captured[0][1]
    assert v['constraints']['releaseDateConstraint']['releaseDateRange']=={'start':'2027-01-01','end':'2027-12-31'}
    assert v['constraints']['genreConstraint']=={'allGenreIds':['Sci-Fi']}
    assert v['constraints']['titleTypeConstraint']['anyTitleTypeIds']==['tvSeries','tvMiniSeries']
    assert v['after']=='page2'

def test_past_year_range_is_empty_without_upstream(captured):
    assert upcoming.upcoming_titles('2026-10-25',end_year='2025')['count']==0
    assert not captured

@pytest.mark.parametrize('value',['','not-a-date','2026-02-30','2026-13-01','9999-01-01'])
def test_invalid_dates_are_rejected(value,captured):
    with pytest.raises(ValueError):upcoming.upcoming_titles(value)
    assert not captured

def test_upcoming_route_and_health_are_registered(tmp_path,captured):
    app=server.make_app(tmp_path/'cache.db')
    assert '/upcoming' in request(app,'/health','')['body'].decode()
    out=request(app,'/upcoming','after=2026-10-25')
    assert out['status'].startswith('200')
    assert '2027-01-15' in out['body'].decode()
