#!/bin/sh
set -eu
SERVICE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SERVICE_DIR"
if [ ! -x .venv/bin/python ]; then
    python3 -m venv .venv
    .venv/bin/python -m pip install --disable-pip-version-check -r requirements.lock
fi
exec .venv/bin/python server.py
