# RGShows self-hosted movie metadata service

Prepared using omkarcloud/imdb-scraper, pinned to commit d90823ea02f6be551319f75502c98a6fc182197a. The original runtime source and MIT license are included under upstream/. The server supplies movie metadata, not playable full-film streams.

## What is ready
The service starts locally, serves /health and the upstream API routes, and caches successful /search responses for 6 hours and /title/details for 7 days in SQLite. API failures are not cached. 37 backend tests pass using captured upstream fixtures and local test responses. Live IMDb connectivity has NOT been verified in this build environment. The production metadata host has not been deployed because no server/domain was supplied. No app users can reach the build environment's loopback server.

## Run on your own server
Requires Python 3.10+ and an internet-connected host. Extract this folder, then run:

    ./start.sh

For Windows, create a virtual environment with python -m venv .venv, install requirements.lock with .venv/Scripts/python -m pip install -r requirements.lock, then run .venv/Scripts/python server.py.

The service listens on 127.0.0.1:8000 by default. Verify locally:

    curl http://127.0.0.1:8000/health
    curl 'http://127.0.0.1:8000/search?query=matrix&type=movie&genre=Sci-Fi'
    curl 'http://127.0.0.1:8000/title/details?title_id=tt0111161'

/health only verifies that the service is running; a successful title-details request verifies upstream connectivity. The server needs outbound access to api.graphql.imdb.com, and v3.sg.media-imdb.com for autocomplete. App poster loading uses supplied HTTPS image URLs, commonly m.media-amazon.com. Keep TLS verification enabled. No API key is required by this self-hosted implementation. Do not add secrets to the Android APK.

## Make it reachable from phones
Point your domain at your server and put the included Caddyfile in front of the service. With Caddy installed and ports 80/443 available, set METADATA_DOMAIN to your real hostname (for example metadata.example.com), then run:

    METADATA_DOMAIN=metadata.example.com caddy run --config Caddyfile

Replace the example with a domain you control. Keep the Python service running under your server's normal process manager. This package does not create a domain, provision a server, configure your firewall, or deploy itself. Caddy obtains the trusted HTTPS certificate. Review capacity and access controls appropriate to your deployment before sharing it widely.

Do not enter localhost or 127.0.0.1 into the phone app: those addresses refer to the phone itself. Do not use a GitHub repository/download URL as the API address. The app requires the running service's HTTPS base URL, such as https://metadata.example.com.

## Connect RGShows
In the metadata preview APK, open 3 sources → Settings → Movie metadata service. Enter the running HTTPS base URL, then Save & load. For a public release, provide the final service URL to the app maintainer so it can be preconfigured for ordinary users. Without a configured, reachable service, the APK cannot fetch the new catalog.

## Filters and language coverage
/search supports query, type (movie or tv), genre, start_year, end_year, sort and cursor. /title/details accepts title_id. The app uses spoken_languages from title details because upstream /search has no language parameter. The Android client enriches each page with details, caches them for 7 days and applies the language filter to the loaded pages. It displays missing language coverage and supports Load more. It does not claim that the first 50 loaded titles are all worldwide matches for a language.

Sci-Fi is normalized to Science Fiction in the UI and mapped back when calling /search. IMDb IDs keep metadata identities separate from playable provider URLs. Metadata never creates or guarantees a playable source link. The three playback providers and native stream resolver remain experimental and are not repaired by this metadata service.

## Configuration
HOST: listening interface, default 127.0.0.1.
PORT: listening port, default 8000.
CACHE_DB: SQLite path, default data/metadata.sqlite3.
IMDB_PROXY: optional upstream project setting for deployments that already use an authorized proxy. No proxy bypass or anti-bot challenge circumvention is added by this package.

## Test
Install pytest into your virtual environment, then run:

    .venv/bin/python -m pytest tests upstream/imdb/test_parsers.py upstream/imdb/test_endpoints.py -q

The runtime dependencies are pinned in requirements.lock. Captured fixtures are used only by tests and are never served as a real catalog.
